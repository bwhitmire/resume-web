var bio = {
	"name" : "Brandon Whitmire",
	"role" : "Sr. Systems Developer",
	"contacts" : {
		"mobile" : "662-313-9833",
		"email" : "brandon.whitmire@gmail.com",
		"github" : "bwhitmire",
		"twitter" : "Brandon31985",
		"location" : "Memphis, TN"
	},
	"welcomeMessage" : "Hello and welcome to my resume!",
	"skills" : [
		"C#", "SQL", "Python", "JavaScript", "HTML5", "Bigfoot Hunter",
		"Amateur Film Maker"
	],
	"biopic" : "images/me.jpg",
	"display" : function(){
		var formattedName = HTMLheaderName.replace("%data%", bio.name);
		var formattedRole = HTMLheaderRole.replace("%data%", bio.role);
		$("#header").prepend(formattedRole);
		$("#header").prepend(formattedName);

		var myMobile = HTMLmobile.replace("%data%", bio.contacts.mobile);
		var myEmail = HTMLemail.replace("%data%", bio.contacts.email);
		var myGithub = HTMLgithub.replace("%data%", bio.contacts.github);
		var myTwitter = HTMLtwitter.replace("%data%", bio.contacts.twitter);
		var myLocation = HTMLlocation.replace("%data%", bio.contacts.location);
		var myWelcomeMsg = HTMLwelcomeMsg.replace("%data%", bio.welcomeMessage);

		$("#topContacts").append(myMobile);
		$("#topContacts").append(myEmail);
		$("#footerContacts").append(myGithub);
		$("#footerContacts").append(myTwitter);
		$("#topContacts").append(myLocation);

		$("#welcome").append(myWelcomeMsg);

		var profilePic = HTMLbioPic.replace("%data%", bio.biopic);
		$("#header").append(profilePic);

		if(bio.skills.length > 0) {
		$("#header").append(HTMLskillsStart);

			bio.skills.forEach(function(skill) {
				var formattedSkill = HTMLskills.replace("%data%", skill);
				$("#skills").append(formattedSkill);
			});
		}
	}
};

var education = {
	"schools" : [
		{
			"name": "Delta State University",
			"location": "Cleveland, MS",
			"degree" : "BBA",
			"majors" : ["Accounting"],
			"dates" : "2007",
			"url" : "www.deltastate.edu"
		},
		{
			"name": "Delta State University",
			"location": "Cleveland, MS",
			"degree" : "Masters",
			"majors" : ["Accounting"],
			"dates" : "2008",
			"url" : "www.deltastate.edu"
		}
	],
	"onlineCourses" : [
		{
			"title": "Intro to Programming",
			"school" : "Udacity",
			"date" : "2016",
			"url" : "https://www.udacity.com/"
		}
	],
	"display" : function() {
		education.schools.forEach(function(school) {
			$("#education").append(HTMLschoolStart);
			var formattedSchoolName = HTMLschoolName.replace("%data%", school.name);
			var formattedSchoolDegree = HTMLschoolDegree.replace("%data%", school.degree);
			var formattedSchoolDates = HTMLschoolDates.replace("%data%", school.dates);
			var formattedSchoolLocation = HTMLschoolLocation.replace("%data%", school.location);
			var formattedSchoolMajor = HTMLschoolMajor.replace("%data%", school.majors);
			$(".education-entry:last").append(formattedSchoolName + formattedSchoolDegree);
			$(".education-entry:last").append(formattedSchoolDates);
			$(".education-entry:last").append(formattedSchoolLocation);
			$(".education-entry:last").append(formattedSchoolMajor);
		});
	$("#education").append(HTMLonlineClasses);
		education.onlineCourses.forEach(function(course) {
			$("#education").append(HTMLschoolStart);
			var formattedOCTitle = HTMLonlineTitle.replace("%data%", course.title);
			var formattedOCSchool = HTMLonlineSchool.replace("%data%", course.school);
			var formattedOCDates = HTMLonlineDates.replace("%data%", course.date);
			var formattedOCURL = HTMLonlineURL.replace("%data%", course.url);
			$(".education-entry:last").append(formattedOCTitle + formattedOCSchool);
			$(".education-entry:last").append(formattedOCDates);
			$(".education-entry:last").append(formattedOCURL);
		});
	}
};

var work = {
	"jobs" : [
		{
			"employer" : "MAA",
			"title" : "Systems Developer",
			"dates" : "February 2014 - Current",
			"location" : "Memphis, TN",
			"description" : "Development work with C#, ASP.net, SQL, and CSS."
		},
		{
			"employer" : "MAA",
			"title" : "Revenue Analyst",
			"dates" : "September 2012 - February 2014",
			"location" : "Memphis, TN",
			"description" : "Conduct pricing calls with properties to adjust unit rents appropriately."	
		},
		{
			"employer" : "MAA",
			"title" : "Utility Analyst",
			"dates" : "July 2009 - September 2012",
			"location" : "Memphis, TN",
			"description" : "Bill utilities back to residents."
		},
		{
			"employer" : "Baxter Healthcare",
			"title" : "Accountant",
			"dates" : "March 2006 - July 2009",
			"location" : "Cleveland, MS",
			"description" : "Cost accounting functions, journal entries, account reconciliations."
		}
	],
	"display" : function() {
		work.jobs.forEach(function(job) {
			$("#workExperience").append(HTMLworkStart);
			var formattedEmployer = HTMLworkEmployer.replace("%data%", job.employer);
			var formattedTitle = HTMLworkTitle.replace("%data%", job.title);
			var formattedEmployerTitle = formattedEmployer + formattedTitle;
			var formattedDate = HTMLworkDates.replace("%data%", job.dates);
			var formattedDescription = HTMLworkDescription.replace("%data%", job.description);
			var formattedLocation = HTMLworkLocation.replace("%data%", job.location);
			$(".work-entry:last").append(formattedEmployerTitle);
			$(".work-entry:last").append(formattedDate);
			$(".work-entry:last").append(formattedDescription);
			$(".work-entry:last").append(formattedLocation);
		});
	}
};

var projects = {
	"projects" : [
		{
			"title" : "Movie Website",
			"dates" : "2016",
			"description" : "Created a movie website using Python.",
			"images" : ["images/movie_project.jpg"]
		}
	],
	"display" : function() {
		projects.projects.forEach(function(project) {
			$("#projects").append(HTMLprojectStart);
			var formattedProjectTitle = HTMLprojectTitle.replace("%data%", project.title);
			$(".project-entry:last").append(formattedProjectTitle);
			var formattedProjectDates = HTMLprojectDates.replace("%data%", project.dates);
			$(".project-entry:last").append(formattedProjectDates);
			var formattedProjectDescription = HTMLprojectDescription.replace("%data%", project.description);
			$(".project-entry:last").append(formattedProjectDescription);

			if(project.images.length > 0) {
				project.images.forEach(function(image) {
					var formattedProjectImage = HTMLprojectImage.replace("%data%", image);
					$(".project-entry:last").append(formattedProjectImage);
				});
			}
		});
	}
};

function inName() {
	var myName = bio.name.split(" ");
	var lastName = myName[1].toUpperCase();
	var firstName = myName[0] = myName[0].slice(0,1).toUpperCase() + 
		myName[0].slice(1).toLowerCase();

	return firstName + " " + lastName;
}

bio.display();
work.display();
education.display();
projects.display();

//Display map.
$("#mapDiv").append(googleMap);

//Embed collision visualization from d3.
var collision = '<embed src="ds-collision.html" width="100%" height="800">';
$("#fun").append(collision);

//Internationalize name.
$("#main").append(internationalizeButton);